var http = require('http');

http.createServer(function (req, res) {
  res.writeHead(200, { 'content-type': 'text/html'});

  console.log('request for url: ' + req.url);
  debugger;

  if (req.url === '/') {
    res.write('Welcome to my home');
  } else if (req.url === '/remy') {
    res.write('Aha, you are me');
  } else {
    res.write('I know nothing about ' + req.url);
  }

  res.end();
}).listen(8000);