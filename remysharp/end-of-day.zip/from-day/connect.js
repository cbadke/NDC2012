var connect = require('connect'),
    ws = require('websocket.io'),
    counter = 0,
    sockets = [];

function exists(code) {
  return {
    'abc': true,
    'xyz': true
  }[code] || false;
}

var routes = function (app) {
  app.get('/:code/:revision/:action', function (req, res, next) {
    if (!exists(req.params.code)) {
      return next();
    }

    res.end('Revision ' + req.params.revision);
  });

  app.get('/remy.json', function (req, res, next) {
    res.writeHead(200, { 'content-type': 'text/html'});
    res.end('Hello Remy - requested ' + req.ctr + ' times');
  });
};

var server = connect()
    .use(connect.logger('tiny'))
    .use(connect.favicon())
    .use(connect.router(routes))
    .use(connect.directory(__dirname + '/public'))
    .use(connect.static(__dirname + '/public'))
    .listen(process.env.PORT || 8000);

ws.attach(server).on('connection', function (socket) {
  sockets.push(socket);

  socket.on('message', function (data) {
    console.log('new message in: ' + data);

    sockets.forEach(function (sock) {
      if (sock !== socket) {
        sock.send(data);
      }
    });

  }).on('close', function () {
    console.log('socket closed');
    var i = sockets.indexOf(socket);
    if (i !== -1) {
      sockets.splice(i, 1);
    }
  });
});








