var path = require('path'),
    doesItExist = false;

console.log('step 1: file exists?');

path.exists(process.argv[2], function (exists) {
  debugger;
  console.log('Exists? ' + exists);
  doesItExist = exists;
});

console.log('step 2: now we wait...');