var connect = require('connect'),
    server = connect(),
    io = require('socket.io').listen(server),
    ctr = 1;

server.use(connect.favicon())
    .use(connect.directory(__dirname + '/public'))
    .use(connect.static(__dirname + '/public'))
    .listen(process.env.PORT || 8000);

io.of('/chat').on('connection', function (socket) {
  console.log('new connect on chat channel');
  socket.on('message', function (msg) {
    console.log('new message', msg);
    socket.broadcast.emit('message', { msg: msg, username: socket.username });
  });

  socket.broadcast.emit('join');
  socket.username = 'guest' + ctr++;
  socket.on('leave', function () {

  }).on('username', function (username, callback) {
    socket.username = (username || socket.username).split('').reverse().join('');
    socket.broadcast.emit('username change', socket.username);
    if (callback) {
      console.log(callback.toString());
      callback(socket.username);
    }
  });
});