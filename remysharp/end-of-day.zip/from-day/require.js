var servedir = require('servedir');

console.log(servedir);