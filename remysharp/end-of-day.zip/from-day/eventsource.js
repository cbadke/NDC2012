var connect = require('connect'),
    connections = [];

setInterval(function () {
  send(new Date().toString());
}, 1000);

function send(str) {
  connections.forEach(function (res) {
    res.write('data: ' + str + '\n\n');
    if (res.xhr) {
      res.end();
      res.req.emit('close');
    }
  });

  console.log(connections.length);
}

var routes = function (app) {
  app.get('/trigger/:cmd', function (req, res, next) {
    send(req.params.cmd);
    res.end('Thanks');
  });
  app.get('/time', function (req, res, next) {
    if (req.headers.accept === 'text/event-stream') {
      connections.push(res);

      res.xhr = req.headers['x-requested-with'].toLowerCase() === 'xmlhttprequest';
      console.log('got eventsource connection. Polyfilled? ' + res.xhr);

      if (res.xhr) res.req = req;

      res.writeHead(200, { 
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache'
      });

      res.write('id\n\n');

      req.on('close', function () {
        var i = connections.indexOf(res);
        if (i !== -1) {
          connections.splice(i, 1);
        }
        console.log('connection closed');
      });
    } else {
      next();
    }
  });
};

var server = connect()
    .use(connect.logger('tiny'))
    .use(connect.favicon())
    .use(connect.router(routes))
    .use(connect.directory(__dirname + '/public'))
    .use(connect.static(__dirname + '/public'))
    .listen(process.env.PORT || 8000);