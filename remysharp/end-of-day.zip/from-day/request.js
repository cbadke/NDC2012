var http = require('http'),
    url = require('url');

var options = url.parse('http://2011.full-frontal.org/schedule');

http.request(options, function (res) {
  console.log(res.statusCode);
  var html = '';

  res.on('data', function (chunk) {
    html += chunk;
  }).on('end', function () {
    debugger;
  });
}).end();